# explicacion del proyecto 2 - filtro de numeros (protocolo estanga)

este proyecto permite subir un archivo `.txt` (generado por el proyecto 1), leerlo en el servidor, y filtrar los numeros que empiezan y terminan con el mismo digito.

## estructura y archivos

### /server.js
el motor del proyecto.
- usa `multer` para recibir los archivos subidos.
- **procesamiento real**: lee el archivo usando `fs.readFile` (nada de leer en el frente).
- filtra los numeros segun la logica: `primer_digito === ultimo_digito`.
- ordena los resultados ascendente (`sort`).
- tiene un endpoint `/guardar-resultado` para generar un nuevo `.txt` con los filtrados en la carpeta `/resultados`.

### /modules/
logica modularizada para el frente:
- **estado.js**: guarda la informacion recibida del server (stats, listas).
- **renderizador.js**: muestra las estadisticas, los porcentajes y la lista de utiles con animaciones neon.

### /scripts/app.js
maneja el envio del archivo al servidor usando `FormData` y recibe los resultados para mandarlos al renderizador.

### /uploads/
carpeta donde se guardan temporalmente los archivos que subis.

### /resultados/
carpeta donde se generan los reportes finales de filtrado.

---
**nota del alumno:** se cumple con el requerimiento de procesar el archivo en el backend. el filtrado incluye el calculo de porcentaje de utilidad y el ordenamiento ascendente solicitado.
