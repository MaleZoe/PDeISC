// server del proyecto 2 - filtrado de numeros
import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import os from 'os';
import { fileURLToPath } from 'url';

// importo la logica del filtro
import { Filtro } from './modules/filtro.js';

// esto es para que el __dirname no llore con los imports
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PUERTO = 3001;

// me aseguro que la carpeta de subida exista
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir);
}

// configuro multer para guardar en uploads/
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: (req, file, cb) => {
    cb(null, `upload_${Date.now()}_${file.originalname}`);
  }
});
const upload = multer({ storage });

app.use(express.json());

// sirvo las carpetas segun el protocolo
app.use('/styles', express.static(path.join(__dirname, 'styles')));
app.use('/scripts', express.static(path.join(__dirname, 'scripts')));
app.use('/modules', express.static(path.join(__dirname, 'modules')));

// ruta principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'pages', 'index.html'));
});

// endpoint para subir y procesar el archivo (LA POSTA)
app.post('/procesar', upload.single('archivo'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ ok: false, error: "no mandaste ni un archivo, pibe" });
  }

  const rutaArchivo = req.file.path;
  console.log(">>> Intentando leer archivo en:", rutaArchivo);

  if (!fs.existsSync(rutaArchivo)) {
      console.error(">>> ERROR: El archivo no existe en el disco!");
      return res.status(500).json({ ok: false, error: "Archivo no encontrado en el servidor" });
  }

  // leo el archivo de verdad usando fs.readFile
  fs.readFile(rutaArchivo, 'utf-8', (err, contenido) => {
    if (err) {
      console.error("error al leer:", err);
      return res.status(500).json({ ok: false, error: "no pude leer el archivo" });
    }

    // separo lineas y limpio
    const lineas = contenido.split(/\r?\n/).filter(line => line.trim() !== "");
    const numeros = lineas.map(l => l.trim()).map(Number).filter(n => !isNaN(n));

    // uso el modulo de filtro como corresponde
    const { utiles, descartados, factoriales } = Filtro.filtrar(numeros);

    // devuelvo todo el bardo al frente
    res.json({
      ok: true,
      archivoOrigen: req.file.originalname,
      totalLeidos: numeros.length,
      totalUtiles: utiles.length,
      totalDescartados: descartados.length,
      numerosUtiles: utiles,
      numerosDescartados: descartados,
      numerosFactoriales: factoriales
    });
  });
});

// endpoint para guardar el resultado final
app.post('/guardar-resultado', (req, res) => {
  const { numerosUtiles, stats } = req.body;

  if (!numerosUtiles || !Array.isArray(numerosUtiles)) {
    return res.status(400).json({ ok: false, error: "falta la data" });
  }

  const hoy = new Date();
  const fecha = `${hoy.getDate().toString().padStart(2, '0')}/${(hoy.getMonth() + 1).toString().padStart(2, '0')}/${hoy.getFullYear().toString().slice(-2)}`;
  
  let contenido = `=== REPORTE DE FILTRADO (ESTANGA) ===\n`;
  contenido += `Fecha: ${fecha}\n`;
  contenido += `Archivo Origen: ${stats.archivoOrigen}\n`;
  contenido += `Total Leidos: ${stats.totalLeidos}\n`;
  contenido += `Utiles: ${stats.totalUtiles} (${stats.porcentajeUtiles}%)\n`;
  contenido += `------------------------------------\n`;
  contenido += numerosUtiles.join('\n');

  const nombreArchivo = `resultado_${Date.now()}.txt`;
  const rutaProyecto = path.join(__dirname, nombreArchivo);

  // 1. guardo en la raiz del proyecto (backend)
  fs.writeFile(rutaProyecto, contenido, 'utf-8', (err) => {
    if (err) return res.status(500).json({ ok: false, error: "no se pudo guardar en el proyecto" });
    
    // 2. LA POSTA: guardo tambien en Downloads de Windows
    const rutaDownloads = path.join(os.homedir(), 'Downloads', nombreArchivo);
    fs.writeFile(rutaDownloads, contenido, 'utf-8', (errDescarga) => {
      if (errDescarga) {
        console.warn("error guardando en Downloads:", errDescarga.message);
      }
      res.json({ ok: true, archivo: nombreArchivo, rutaLocal: rutaDownloads });
    });
  });
});

// prendo el server
app.listen(PUERTO, () => {
  console.log(`>>> server del filtro andando en http://localhost:${PUERTO}`);
});
