# explicacion del proyecto 1 - colector de numeros (protocolo estanga)

este proyecto es una aplicacion web para juntar numeros y sacar estadisticas. esta hecho con node.js y express para el server, y javascript puro para el frente, siguiendo estrictamente el protocolo estanga.

## estructura y archivos

### /server.js
es el corazon del bardo. aca prendemos el servidor con express en el puerto 3000.
- usa imports (esm) modernos.
- tiene un endpoint `/exportar` que recibe la lista de numeros y genera un archivo `numeros_exportados.txt` real en la carpeta `/txt`.
- **importante**: el archivo solo guarda los numeros puros (uno por linea) para que el proyecto 2 lo pueda procesar sin romperse.

### /modules/
aca esta la logica modularizada que se importa desde el frente:
- **estado.js**: maneja el array real de numeros y las cuentas (promedio, maximo, minimo). valida el minimo de 10 y maximo de 20.
- **validador.js**: vigila que no metas fruta (letras, vacio, etc).
- **renderizador.js**: dibuja todo dinamicamente, maneja animaciones y el feedback visual (toasts).

### /scripts/app.js
es el director de orquesta. conecta los modulos con el dom y maneja los eventos de los botones.

### /styles/
- **estilos.css**: toda la facha neon y premium del laboratorio.
- **dark.css** y **light.css**: las variables de colores para el switch de modo.

### /txt/
carpeta donde se guardan los archivos generados de verdad.

---
**nota del alumno:** se cumple con la validacion de minimo 10 numeros antes de dejar exportar, se usa un array real y el renderizado es 100% dinamico.
